import os
import time

os.system("pkill main")

time.sleep(9)
with open('PID', 'w') as file:
    file.write(str(os.getpid()))
os.system("./main")
