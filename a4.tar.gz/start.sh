python3 cock.py
