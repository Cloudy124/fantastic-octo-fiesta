pip3 install selenium
python3 cock.py
